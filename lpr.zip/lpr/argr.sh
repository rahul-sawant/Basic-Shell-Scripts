echo "First argument:$1"
echo "Shifting first argument's position by 1"
shift 1
echo "Now first argument:$1"
echo "Now shifting first argument's position with 2nd"
shift 2
echo "Now first argument:$1"
echo "Now shifting position with 4"
shift 6
echo "Now first argument:$1"