exec 7<Pikapi
who
date <&7
echo "End of script"
date '+%d -%b -%y' <&7
