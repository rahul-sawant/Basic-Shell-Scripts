num1=230
num2=240
num3=250
num4=140
if [ $num1 -eq $num2 ] 
then echo "$num1 is Equal to $num2"
fi
if [ $num1 -ne $num2 ]
then
echo "$num1 is not eqal to $num2"
fi
if [ $num3 -lt $num4 ]
then
echo "$num3 is less then $num4"
fi
if [ $num1 -gt $num4 ]
then
echo "$num1 is greater then $num4"
fi
