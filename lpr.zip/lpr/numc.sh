n1=123
n2=564
if [ $n1 = $n2 ]
then
echo "Number 1 & Number 2 are equal"
fi
if [ $n1 != $n2 ]
then 
echo "Number 1 & Number 2 aren't equal"
fi