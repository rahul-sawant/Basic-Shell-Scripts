exec 2>Today
who am i
pwd
echo "Pikachu ^_^"
ls
pika