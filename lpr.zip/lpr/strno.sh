str1=$1
str2=$2
str3=$3
echo "$str1 $str2 $str3"
echo "File name of current script "$0""
echo "$n"
echo "Number of argument are "$#""
echo "$*"
echo "The exit status of last command executed is "$?""
echo "The last command line parameter variable "%{!#}""