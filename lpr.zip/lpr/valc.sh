a=10
b=20
if [ $a -eq $b ]
then
echo "Values are same"
else
echo " Values aren't same"
fi